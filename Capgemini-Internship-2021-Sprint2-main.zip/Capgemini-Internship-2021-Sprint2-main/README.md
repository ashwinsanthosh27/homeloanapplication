# Capgemini-Internship-2021-Sprint2
Sprint 2 Java Full Stack Project : Home Loan Application

About the project:-

To Create an Application for online Home Loan Application Customer should be able to , apply for home loan hassle-free,keep a track of their status and can view available services, policies, benefits and other information related to a specific loan without visiting any bank branch.

Admin should be able to perform below operations: 1.View all pending approvals 2.Approve/Reject applications 3.Create new schemes Other officers like LandVerificationOfficer and FinanceOfficer should be able to : View pending tickets Verify and report the status after LandVerification ,upon approval will raise a ticket for FInanceOfficer upon approval will send the application to Admin

Application will be developed in following Sprints :-

1.Core Java +JPA with Hibernate 2.Spring Boot + Rest Controller + JPA with Hibernate 3.Angular for UI design (Front End) + Integration with previous Sprint

Project Submitted By :-

1. JA - 16 Anshuman Biswal      anshumanbiswal14@gmail.com         G4   Home Loan App
2. JA - 16 Ashwin Sp            ashwinsanthosh27@gmail.com         G4   Home Loan App
3. JA - 16 Bharath Surya J      bharathsurya1@gmail.com            G4   Home Loan App
4. JA - 16 Blesy Helen V        blesyhelen996@gmail.com            G4   Home Loan App
5. JA - 16 Gaurav Shrivastava   gauravdb34@gmail.com               G4   Home Loan App
