import { User } from "./User";

export class LandVerificationOfficer extends User {

  officerName!: string;
  officerContact!: string;
}