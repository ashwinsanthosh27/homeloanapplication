export class EMI{
    EMIId!: number;
	dueDate!: Date;
	emiAmount!: number;
	loanAmount!: number;
	interestAmount!: number;
}