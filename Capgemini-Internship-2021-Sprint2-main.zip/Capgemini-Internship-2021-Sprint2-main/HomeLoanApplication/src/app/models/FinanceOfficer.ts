import { User } from "./User";

export class FinanceVerificationOfficer  extends User{
  finOfficerName !: string;
  finOfficerContact !: string;
}
