export class User{
  userId!:number;
  username!:String;
  password!:String;
}