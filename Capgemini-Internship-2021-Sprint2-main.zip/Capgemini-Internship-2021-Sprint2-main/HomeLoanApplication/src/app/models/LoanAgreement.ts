import { EMI } from "./EMI";

export class LoanAgreement{
    loanAgreementId!: number;
	loanApplicationId!: number;
    emi!: EMI;
}