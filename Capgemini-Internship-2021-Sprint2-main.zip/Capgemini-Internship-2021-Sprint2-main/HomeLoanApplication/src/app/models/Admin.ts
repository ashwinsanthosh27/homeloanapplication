import { User } from "./User";

export class Admin extends User {
  adminName!: string;
  adminContact!: string;
}